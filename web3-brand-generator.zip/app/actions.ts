"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function generateBrandAssets(formData: FormData) {
  try {
    const brandName = formData.get("brandName") as string
    const objectsThemes = formData.get("objectsThemes") as string
    const brandColor1 = formData.get("brandColor1") as string
    const brandColor2 = formData.get("brandColor2") as string
    const brandColor3 = formData.get("brandColor3") as string
    const logo = formData.get("logo") as File

    // Convert logo to base64 for sending to OpenAI
    const logoBuffer = await logo.arrayBuffer()
    const logoBase64 = Buffer.from(logoBuffer).toString("base64")
    const logoMimeType = logo.type

    // Create the prompt for OpenAI
    const prompt = `
      I need a complete brand asset system for a Web3 brand called "${brandName}".
      The brand is associated with these objects or themes: "${objectsThemes}".
      The brand already has these three colors: ${brandColor1}, ${brandColor2}, ${brandColor3}.
      
      Please analyze this information and generate a complete brand asset system based on academic design frameworks.
      
      1. Extract brand personality traits using Aaker's Brand Personality Framework (1997).
      2. Suggest a 5-color palette (including the three provided colors) using Labrecque & Milne (2012) color–emotion associations.
      3. Propose a primary logo icon concept (symbolic, textless, Web3-appropriate).
      4. Propose a full logo concept (icon + brand name typography).
      5. Suggest a typography system (display + body font pairing).
      6. Provide a social media kit concept:
         - Twitter/X header
         - Discord banner
         - Post templates
      
      Briefly explain each choice (colors, fonts, icon) with reference to the frameworks.
      Keep all output Web3-centric, minimalist, and scalable.
      
      Format your response as a JSON object with the following structure:
      {
        "personality": {
          "traits": ["trait1", "trait2", "trait3", "trait4", "trait5"],
          "description": "Description of the brand personality"
        },
        "colorPalette": {
          "colors": ["${brandColor1}", "${brandColor2}", "${brandColor3}", "color4", "color5"],
          "explanation": "Explanation of the color palette"
        },
        "typography": {
          "display": "Display font name",
          "body": "Body font name",
          "explanation": "Explanation of the typography choices"
        },
        "logoIcon": {
          "description": "Description of the logo icon",
          "explanation": "Explanation of the logo icon design"
        },
        "fullLogo": {
          "description": "Description of the full logo"
        },
        "socialMedia": {
          "twitter": "Description of Twitter/X header",
          "discord": "Description of Discord banner",
          "postTemplates": "Description of post templates"
        }
      }
    `

    // Generate the brand assets using OpenAI
    const { text } = await generateText({
      model: openai("gpt-3.5-turbo"),
      prompt,
      temperature: 0.7,
      maxTokens: 2000,
    })

    // Parse the response as JSON
    const brandAssets = JSON.parse(text)

    return brandAssets
  } catch (error) {
    console.error("Error generating brand assets:", error)
    return { error: "Failed to generate brand assets. Please try again." }
  }
}
