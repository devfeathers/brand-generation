import BrandGenerator from "@/components/brand-generator"

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-[#969696]">
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <header className="mb-12 text-center">
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-2 text-black">
            Glyph <span className="text-[#F7AB4F]">5.5</span> — AI Brand Generator
          </h1>
          <p className="text-xl text-[#969696]">Get started by completing the details below</p>
        </header>

        <BrandGenerator />
      </div>
    </main>
  )
}
