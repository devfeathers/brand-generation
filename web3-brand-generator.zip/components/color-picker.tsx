"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"

interface ColorPickerProps {
  value: string
  onChange: (value: string) => void
}

export default function ColorPicker({ value, onChange }: ColorPickerProps) {
  const [color, setColor] = useState(value)

  useEffect(() => {
    setColor(value)
  }, [value])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newColor = e.target.value
    setColor(newColor)
    onChange(newColor)
  }

  return (
    <div className="flex items-center space-x-2">
      <div className="h-10 w-10 rounded-md border border-gray-200" style={{ backgroundColor: color }} />
      <Input type="text" value={color} onChange={handleChange} className="bg-white border-gray-200 text-[#5C5C5C]" />
      <Input type="color" value={color} onChange={handleChange} className="w-10 h-10 p-1 bg-transparent border-0" />
    </div>
  )
}
