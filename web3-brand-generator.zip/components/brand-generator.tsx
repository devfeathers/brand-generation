"use client"

import type React from "react"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Loader2 } from "lucide-react"
import { generateBrandAssets } from "@/app/actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import BrandResults from "@/components/brand-results"
import ColorPicker from "@/components/color-picker"

const formSchema = z.object({
  brandName: z.string().min(1, "Brand name is required"),
  objectsThemes: z.string().min(1, "Objects or themes are required"),
  brandColor1: z.string().regex(/^#([A-Fa-f0-9]{6})$/, "Must be a valid hex color"),
  brandColor2: z.string().regex(/^#([A-Fa-f0-9]{6})$/, "Must be a valid hex color"),
  brandColor3: z.string().regex(/^#([A-Fa-f0-9]{6})$/, "Must be a valid hex color"),
})

type FormValues = z.infer<typeof formSchema>

export default function BrandGenerator() {
  const [logo, setLogo] = useState<File | null>(null)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [results, setResults] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      brandName: "",
      objectsThemes: "",
      brandColor1: "#F7AB4F",
      brandColor2: "#3B82F6",
      brandColor3: "#10B981",
    },
  })

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.type !== "image/png") {
        setError("Please upload a PNG file")
        return
      }
      setLogo(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setLogoPreview(reader.result as string)
      }
      reader.readAsDataURL(file)
      setError(null)
    }
  }

  const onSubmit = async (data: FormValues) => {
    try {
      setIsSubmitting(true)
      setError(null)

      if (!logo) {
        setError("Please upload a logo")
        setIsSubmitting(false)
        return
      }

      const formData = new FormData()
      formData.append("brandName", data.brandName)
      formData.append("objectsThemes", data.objectsThemes)
      formData.append("brandColor1", data.brandColor1)
      formData.append("brandColor2", data.brandColor2)
      formData.append("brandColor3", data.brandColor3)
      formData.append("logo", logo)

      const result = await generateBrandAssets(formData)

      if (result.error) {
        setError(result.error)
      } else {
        setResults(result)
        // Scroll to results
        setTimeout(() => {
          document.getElementById("results")?.scrollIntoView({ behavior: "smooth" })
        }, 100)
      }
    } catch (err) {
      setError("An error occurred while generating brand assets")
      console.error(err)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-12">
      <div className="bg-gray-100 rounded-xl p-6 border border-gray-200">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="brandName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[#5C5C5C]">Brand Name</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter your brand name"
                      {...field}
                      className="bg-white border-gray-200 text-[#5C5C5C]"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="objectsThemes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-[#5C5C5C]">Objects or Themes</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter objects or themes related to your brand"
                      {...field}
                      className="bg-white border-gray-200 text-[#5C5C5C]"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-3">
              <Label className="text-[#5C5C5C]">Upload Logo (PNG)</Label>
              <div className="flex items-center gap-4">
                <Input
                  type="file"
                  accept="image/png"
                  onChange={handleLogoChange}
                  className="bg-white border-gray-200 text-[#5C5C5C]"
                />
                {logoPreview && (
                  <div className="h-12 w-12 rounded-md overflow-hidden bg-slate-700 flex items-center justify-center">
                    <img
                      src={logoPreview || "/placeholder.svg"}
                      alt="Logo preview"
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-[#5C5C5C]">Brand Colors</Label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="brandColor1"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[#5C5C5C]">Primary Color</FormLabel>
                      <FormControl>
                        <ColorPicker value={field.value} onChange={field.onChange} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="brandColor2"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[#5C5C5C]">Secondary Color</FormLabel>
                      <FormControl>
                        <ColorPicker value={field.value} onChange={field.onChange} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="brandColor3"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-[#5C5C5C]">Accent Color</FormLabel>
                      <FormControl>
                        <ColorPicker value={field.value} onChange={field.onChange} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-900/30 border border-red-800 text-red-200 px-4 py-2 rounded-md">{error}</div>
            )}

            <div className="flex justify-start">
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-gradient-to-r from-[#F7AB4F] to-amber-500 hover:from-amber-500 hover:to-amber-600 text-white font-bold"
                size="lg"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Brand Assets...
                  </>
                ) : (
                  "Generate Brand Assets"
                )}
              </Button>
            </div>
          </form>
        </Form>
      </div>

      {results && (
        <div id="results">
          <BrandResults results={results} />
        </div>
      )}
    </div>
  )
}
