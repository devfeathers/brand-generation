"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Copy, Check } from "lucide-react"

interface BrandResultsProps {
  results: {
    personality: {
      traits: string[]
      description: string
    }
    colorPalette: {
      colors: string[]
      explanation: string
    }
    typography: {
      display: string
      body: string
      explanation: string
    }
    logoIcon: {
      description: string
      explanation: string
    }
    fullLogo: {
      description: string
    }
    socialMedia: {
      twitter: string
      discord: string
      postTemplates: string
    }
  }
}

export default function BrandResults({ results }: BrandResultsProps) {
  const [copiedColor, setCopiedColor] = useState<string | null>(null)

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopiedColor(text)
    setTimeout(() => setCopiedColor(null), 2000)
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <h2 className="text-3xl font-bold tracking-tight text-black">Your Brand Assets</h2>

      <Tabs defaultValue="personality" className="w-full">
        <TabsList className="grid grid-cols-3 md:grid-cols-6 bg-gray-100 border border-gray-200">
          <TabsTrigger value="personality">Personality</TabsTrigger>
          <TabsTrigger value="colors">Colors</TabsTrigger>
          <TabsTrigger value="typography">Typography</TabsTrigger>
          <TabsTrigger value="logo">Logo</TabsTrigger>
          <TabsTrigger value="fullLogo">Full Logo</TabsTrigger>
          <TabsTrigger value="social">Social Media</TabsTrigger>
        </TabsList>

        <TabsContent value="personality" className="mt-6">
          <Card className="bg-gray-100 border-gray-200 text-[#5C5C5C]">
            <CardHeader>
              <CardTitle>Brand Personality</CardTitle>
              <CardDescription className="text-[#5C5C5C]">
                Based on Aaker's Brand Personality Framework (1997)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                {results.personality.traits.map((trait, index) => (
                  <Badge
                    key={index}
                    className="bg-[#F7AB4F]/20 text-[#F7AB4F] hover:bg-[#F7AB4F]/30 border-[#F7AB4F]/30"
                  >
                    {trait}
                  </Badge>
                ))}
              </div>
              <Separator className="bg-gray-200" />
              <div className="text-[#5C5C5C]">{results.personality.description}</div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="colors" className="mt-6">
          <Card className="bg-gray-100 border-gray-200 text-[#5C5C5C]">
            <CardHeader>
              <CardTitle>Color Palette</CardTitle>
              <CardDescription className="text-[#5C5C5C]">
                Based on Labrecque & Milne (2012) color–emotion associations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-5 gap-2 h-24">
                {results.colorPalette.colors.map((color, index) => (
                  <div
                    key={index}
                    className="relative rounded-md overflow-hidden group cursor-pointer"
                    onClick={() => copyToClipboard(color)}
                    style={{ backgroundColor: color }}
                  >
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity">
                      {copiedColor === color ? (
                        <Check className="h-5 w-5 text-white" />
                      ) : (
                        <Copy className="h-5 w-5 text-white" />
                      )}
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-xs p-1 text-center">{color}</div>
                  </div>
                ))}
              </div>
              <Separator className="bg-gray-200" />
              <div className="text-[#5C5C5C]">{results.colorPalette.explanation}</div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="typography" className="mt-6">
          <Card className="bg-gray-100 border-gray-200 text-[#5C5C5C]">
            <CardHeader>
              <CardTitle>Typography System</CardTitle>
              <CardDescription className="text-[#5C5C5C]">Display and body font pairing</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-slate-400 mb-2">Display Font</h3>
                  <div className="text-3xl" style={{ fontFamily: "system-ui" }}>
                    {results.typography.display}
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-slate-400 mb-2">Body Font</h3>
                  <div className="text-base" style={{ fontFamily: "system-ui" }}>
                    {results.typography.body}
                  </div>
                </div>
              </div>
              <Separator className="bg-gray-200" />
              <div className="text-[#5C5C5C]">{results.typography.explanation}</div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logo" className="mt-6">
          <Card className="bg-gray-100 border-gray-200 text-[#5C5C5C]">
            <CardHeader>
              <CardTitle>Primary Logo Icon</CardTitle>
              <CardDescription className="text-[#5C5C5C]">Symbolic, textless, Web3-appropriate</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-white p-6 rounded-md border border-gray-200 flex items-center justify-center">
                <div className="text-center text-slate-400 italic">{results.logoIcon.description}</div>
              </div>
              <Separator className="bg-gray-200" />
              <div className="text-[#5C5C5C]">{results.logoIcon.explanation}</div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="fullLogo" className="mt-6">
          <Card className="bg-gray-100 border-gray-200 text-[#5C5C5C]">
            <CardHeader>
              <CardTitle>Full Logo</CardTitle>
              <CardDescription className="text-[#5C5C5C]">Icon + brand name typography</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-white p-6 rounded-md border border-gray-200 flex items-center justify-center">
                <div className="text-center text-slate-400 italic">{results.fullLogo.description}</div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social" className="mt-6">
          <Card className="bg-gray-100 border-gray-200 text-[#5C5C5C]">
            <CardHeader>
              <CardTitle>Social Media Kit</CardTitle>
              <CardDescription className="text-[#5C5C5C]">
                Twitter/X header, Discord banner, and post templates
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-slate-400 mb-2">Twitter/X Header</h3>
                  <div className="bg-white p-4 rounded-md border border-gray-200">
                    <p className="text-slate-400 italic">{results.socialMedia.twitter}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-slate-400 mb-2">Discord Banner</h3>
                  <div className="bg-white p-4 rounded-md border border-gray-200">
                    <p className="text-slate-400 italic">{results.socialMedia.discord}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-slate-400 mb-2">Post Templates</h3>
                  <div className="bg-white p-4 rounded-md border border-gray-200">
                    <p className="text-slate-400 italic">{results.socialMedia.postTemplates}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
